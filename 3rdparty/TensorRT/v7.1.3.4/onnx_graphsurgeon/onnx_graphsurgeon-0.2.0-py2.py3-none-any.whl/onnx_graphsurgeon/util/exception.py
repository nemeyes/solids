class OnnxGraphSurgeonException(Exception):
    pass
